import axios from "axios"

const API_URL = "http://localhost:8080/auth"

class AuthService {
  async login(credentials) {
    const response = await axios.post(`${API_URL}/login`, credentials, {
      headers: { "Content-Type": "application/json" },
    })

    const user = response.data.user
    localStorage.setItem("user", JSON.stringify(user))
    localStorage.setItem("token", response.data.token)

    return response.data
  }

  async register(userData) {
    return axios.post(`${API_URL}/register`, userData, {
      headers: { "Content-Type": "application/json" },
    })
  }

  logout() {
    localStorage.removeItem("user")
    localStorage.removeItem("token")
  }

  getUser() {
    return JSON.parse(localStorage.getItem("user"))
  }

  getToken() {
    return localStorage.getItem("token")
  }

  getCurrentUser() {
    return this.getUser()
  }

  setUser(user) {
    localStorage.setItem("user", JSON.stringify(user))
  }
}

export default new AuthService()
